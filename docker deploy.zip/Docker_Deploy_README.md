# Egypt E-Commerce Personalization Engine — Deployment Runbook

End-to-end Docker deployment of the Big Data pipeline.
Stack: **Hadoop HDFS · Spark · Airflow · Kafka · Postgres · Streamlit**.

> **Source data**: the pipeline ingests the **enhanced Silver dataset**
> (`silver_*.csv`) where the 8 documented ETL fixes have already been
> applied at source. The Silver stage of the pipeline therefore runs
> as a **validation gate** (PK/FK + 8 anti-regression checks) rather
> than re-applying transformations. Any regression fails the run loudly.

---

## 1. What gets deployed

| Service                | Port  | URL                          | Credentials              |
|------------------------|-------|------------------------------|--------------------------|
| **Streamlit dashboard**| 8501  | http://localhost:8501        | —                        |
| Airflow                | 8089  | http://localhost:8089        | `admin` / `admin`        |
| Spark master UI        | 8080  | http://localhost:8080        | —                        |
| Spark worker UI        | 8082  | http://localhost:8082        | —                        |
| Jupyter (PySpark)      | 8888  | http://localhost:8888        | no token                 |
| HDFS namenode UI       | 9870  | http://localhost:9870        | —                        |
| HDFS datanode UI       | 9864  | http://localhost:9864        | —                        |
| pgAdmin                | 8085  | http://localhost:8085        | `admin@admin.com` / `admin` |
| Kafka UI               | 8090  | http://localhost:8090        | —                        |
| Kafka broker           | 9092  | `localhost:9092`             | —                        |
| Postgres (Airflow)     | —     | internal                     | `airflow` / `airflow`    |
| Postgres (project)     | 5432  | `localhost:5432`             | `admin` / `admin`        |

---

## 2. Repository layout

```
project/
├── docker-compose.yaml              # your existing file (untouched)
├── docker-compose.override.yaml     # NEW · adds Streamlit + Spark conn + jobs mount
├── requirements.txt                 # UPDATED · pyspark, hdfs, pandas, etc.
├── dags/
│   ├── 01_data_pipeline.py          # Bronze → Silver → Gold → Models
│   └── 02_retrain_only.py           # nightly model-only retrain
├── spark_jobs/
│   ├── 01_bronze_ingest.py          # silver_*.csv → HDFS Bronze (typed)
│   ├── 02_silver_validate.py        # integrity gate (9 PK + 9 FK + 8 anti-regression)
│   ├── 03_gold_features.py          # RFM, interactions, popularity
│   └── 04_train_models.py           # co-occurrence + ALS + dashboard views
├── dashboard/
│   ├── Dockerfile                   # Streamlit container
│   ├── app.py                       # the dashboard itself
│   └── requirements.txt
├── shared/                          # mounted into all compute services as /data
│   ├── raw/                         # ← drop the 9 EG-ecom CSVs here
│   └── dashboard/                   # auto-populated by Spark
└── scripts/
    ├── start.sh                     # one-command bring-up
    ├── upload_data.sh               # verify CSVs (+ optional HDFS push)
    └── verify_stack.sh              # health-check all services
```

---

## 3. First-time bring-up (≈ 5 minutes)

### Prerequisites
- Docker Desktop 4.x or Docker Engine 24.x
- 8 GB RAM available to Docker
- The 9 enhanced Silver CSV files (from `EG_Ecommerce_Silver_CSVs.zip`)

### Steps

```bash
# 0) Place every file from this bundle into your project root
#    (keep your existing docker-compose.yaml exactly as it is)

# 1) Drop the 9 Silver CSVs into ./shared/raw/
unzip EG_Ecommerce_Silver_CSVs.zip -d ./shared/raw/

# 2) Make the scripts executable
chmod +x scripts/*.sh

# 3) Bring everything up
./scripts/start.sh
```

`start.sh` does four things:
1. Creates the local folders Compose expects (`logs/`, `plugins/`, `pip-cache/`, …).
2. Runs `docker compose up -d` — Compose **auto-merges** your `docker-compose.yaml` with the `docker-compose.override.yaml` from this bundle.
3. Waits ~25 seconds for containers to initialize.
4. Calls WebHDFS to create `/eg_ecom/{bronze,silver,gold,models}` directories.

### Verify

```bash
./scripts/verify_stack.sh
```

Expect 9 ✅ rows. If anything is ❌, check `docker compose logs <service-name>`.

---

## 4. Running the pipeline

### Option A — via Airflow UI (recommended)

1. Open **http://localhost:8089**, login `admin` / `admin`.
2. Find the DAG **`01_data_pipeline`** and toggle it **ON**.
3. Click **Trigger DAG** (▶ icon). Watch the 5 tasks turn green in sequence:
   - `init_hdfs_layout` (< 5 s)
   - `bronze_ingest` (~ 30 s — ingest enhanced CSVs with typed schemas)
   - `silver_validate` (~ 30 s — 9 PK + 9 FK + 8 anti-regression checks, then promote)
   - `gold_features` (~ 1 min — RFM, interactions, popularity)
   - `train_models` (~ 2 min — ALS + co-occurrence + dashboard views)
4. Total runtime: **~ 4 minutes** on a laptop.

### Option B — via Airflow CLI

```bash
docker exec airflow-scheduler airflow dags trigger 01_data_pipeline
docker exec airflow-scheduler airflow dags list-runs -d 01_data_pipeline
```

---

## 5. Viewing results

Once the DAG finishes:

1. Open **http://localhost:8501** (Streamlit dashboard).
2. Click **🔄 Refresh data** in the sidebar.
3. The 5 tabs populate with live data:
   - **Overview** — ETL fix status + top categories
   - **Geography** — customers across the 27 Egyptian governorates
   - **Orders & Payments** — status & payment-type breakdown (in EGP)
   - **Customer Segments** — RFM segment distribution
   - **Recommendations** — Popularity (Tier 1) + ALS (Tier 3) results

The dashboard reads from `./shared/dashboard/*.parquet` (written by the `train_models` Spark job), so it loads instantly — no Spark query at request time.

---

## 6. Verifying via Hive-style queries

You don't have Hive in the compose, but Spark SQL on Parquet gives you the same querying ability:

```bash
# Open a PySpark shell in the jupyter container
docker exec -it jupyter bash -c "pyspark"
```

```python
df = spark.read.parquet("hdfs://namenode:9000/eg_ecom/silver/customers")
df.createOrReplaceTempView("customers")
spark.sql("""
  SELECT customer_governorate, COUNT(*) AS cnt
  FROM customers
  GROUP BY customer_governorate
  ORDER BY cnt DESC LIMIT 10
""").show()
```

Or use the **Jupyter notebook** at http://localhost:8888 — pre-configured with `SPARK_MASTER=spark://spark:7077`.

---

## 7. Inspecting HDFS

Two ways:

**Browser:** http://localhost:9870 → *Utilities → Browse the file system* → `/eg_ecom/`

**CLI inside the namenode container:**
```bash
docker exec namenode hdfs dfs -ls /eg_ecom/silver/
docker exec namenode hdfs dfs -du -h /eg_ecom/
```

Expected layout after a full pipeline run:
```
/eg_ecom/
├── bronze/    (9 tables, ~ 30 MB total)
├── silver/    (9 tables — cleaned, ~ 30 MB)
├── gold/      (rfm_scores, user_item_interactions, item_popularity, item_metadata, user_index, item_index)
└── models/    (item_cooccurrence, als/, top_recommendations)
```

---

## 8. Re-runs and retraining

| Use case                                | DAG to trigger          |
|------------------------------------------|-------------------------|
| First run / full refresh                 | `01_data_pipeline`      |
| Just retrain models on existing Gold     | `02_retrain_only`       |
| Nightly automatic                        | (already scheduled)     |

Both DAGs are idempotent — re-running them overwrites the output Parquet files.

---

## 9. Common operations

```bash
# Bring everything DOWN (keeps data volumes)
docker compose down

# Bring DOWN and WIPE all data (Postgres, HDFS, pgAdmin)
docker compose down -v

# Tail logs from a specific service
docker compose logs -f airflow-scheduler
docker compose logs -f spark
docker compose logs -f streamlit

# Restart just one service
docker compose restart streamlit

# Shell into a container
docker exec -it spark bash
docker exec -it namenode bash
docker exec -it airflow-scheduler bash
```

---

## 10. Troubleshooting

| Symptom                                            | Cause / Fix                                                                    |
|----------------------------------------------------|---------------------------------------------------------------------------------|
| Streamlit shows "No data in /data/dashboard"        | Run the DAG `01_data_pipeline` first.                                          |
| DAG `SparkSubmitOperator` fails: connection refused | Make sure the `spark` container is healthy (`docker compose logs spark`).      |
| `airflow connections list` doesn't show `spark_default` | The override sets it via env var `AIRFLOW_CONN_SPARK_DEFAULT`. Restart Airflow: `docker compose restart airflow-webserver airflow-scheduler`. |
| HDFS `init_hdfs_layout` task fails                 | Namenode might still be starting. Re-run the DAG; the task is idempotent.       |
| Spark job OOM                                       | Bump `spark.driver.memory` / `spark.executor.memory` in `dags/01_data_pipeline.py`. |
| "No DAGs visible in Airflow"                        | Wait 30 s for DAG-bag refresh, or run `docker exec airflow-scheduler airflow dags list`. |
| Dashboard charts empty after refresh                | Click **Refresh data** in the sidebar (clears the Streamlit cache).            |
| Permission denied writing to `./shared/`            | On Linux, `chmod -R 777 ./shared/` once (the airflow user is uid 50000).        |

---

## 11. What runs where

```
┌─────────────────────────────────────────────────────────────────┐
│  Enhanced Silver CSVs (./shared/raw/silver_*.csv)               │
│      │   — 8 ETL fixes pre-applied at source                    │
│      ▼                                                           │
│  Spark job 01_bronze_ingest.py                                  │
│      │   submitted by Airflow DAG step `bronze_ingest`           │
│      ▼                                                           │
│  HDFS /eg_ecom/bronze/   (9 tables, Parquet · Snappy, typed)    │
│      │                                                           │
│      ▼  silver_validate Spark job — INTEGRITY GATE              │
│      │  • 9 PK uniqueness checks                                 │
│      │  • 9 FK referential-integrity checks                      │
│      │  • 8 anti-regression checks (one per ETL fix)             │
│      ▼  (fails the run loudly if any check breaks)               │
│  HDFS /eg_ecom/silver/   (orders partitioned by year/month)      │
│      │                                                           │
│      ▼  gold_features Spark job builds RFM + interactions       │
│  HDFS /eg_ecom/gold/                                             │
│      │                                                           │
│      ▼  train_models Spark job: ALS + co-occurrence             │
│  HDFS /eg_ecom/models/   +   ./shared/dashboard/*.parquet        │
│                                       │                          │
│                                       ▼                          │
│                              Streamlit dashboard :8501           │
└─────────────────────────────────────────────────────────────────┘
```

---

## 12. Phase mapping to the roadmap

| Roadmap phase                       | Weeks   | This deployment covers                                |
|-------------------------------------|---------|-------------------------------------------------------|
| **Phase 1** · Foundations & Setup   | 1–4     | Full Docker stack, HDFS layout, EDA via Jupyter       |
| **Phase 2** · Big Data Engineering  | 5–8     | Bronze→Silver ETL fixes, Gold feature store           |
| **Phase 3** · Intelligence & Models | 9–12    | Popularity, Co-occurrence, ALS models                 |
| **Phase 4** · Deployment            | 13–16   | Airflow DAGs, Streamlit dashboard, end-to-end demo    |

For the Azure cloud lift (Phase 4 extension), see the original `Team_Project_Plan.docx` §5.4.
